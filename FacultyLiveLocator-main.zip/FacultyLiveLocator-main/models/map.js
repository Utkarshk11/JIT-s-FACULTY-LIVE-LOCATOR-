const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const mapSchema = new mongoose.Schema({
    kmlUrls: [String],
    // userLocation: {
    //   latitude: Number,
    //   longitude: Number,
    // }
  });

module.exports = mongoose.model("Map", mapSchema);