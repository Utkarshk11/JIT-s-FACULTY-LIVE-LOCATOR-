const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const passportLocalMongoose = require("passport-local-mongoose");

const teacherSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String,
    location: {
        lat: Number,
        lng: Number
    },
    lastUpdated: Date
});

teacherSchema.plugin(passportLocalMongoose); 

module.exports = mongoose.model("Teacher", teacherSchema);